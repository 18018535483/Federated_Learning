class parameter:
    def __init__(self):
        self.acc_list = []
        self.client = set()
        self.client_msg = {}
        self.epoch = 0
        self.epoch_limit = 10
        self.index = ""
        self.model_data = {}
        self.thread_list = []
        self.threshold = 5
        self.timestamp = 0
        self.time_list = []
        self.time_out = 30


para = parameter()
